from typing import Optional
from discord.ext import commands
from discord.interactions import Interaction
from discord.ui import Button, View



import asyncio, os, random, sys, io, textwrap, traceback, discord, datetime, aiohttp, psutil

from Extra import config



class AutoModeration(commands.Cog, name="Auto Moderation"):
    def __init__(self, bot):
      self.bot = bot
      self.cd = commands.CooldownMapping.from_cooldown(2, 3, commands.BucketType.user)

    async def cog_load(self):
        c = await self.bot.db.cursor()
        await c.execute("CREATE TABLE IF NOT EXISTS automod(guild_id TEXT, antiword TEXT, antilink TEXT, antispam TEXT)")
        await self.bot.db.commit()

    @commands.group()
    async def automod(self, ctx):
        await ctx.send_help(ctx.command)
    
    @automod.command()
    async def setup(self, ctx):
        c = await self.bot.db.cursor()
        await c.execute("SELECT antiword, antilink, antispam FROM automod WHERE guild_id = ?", (ctx.guild.id,))
        re = await c.fetchone()

        if re is not None: return await ctx.send("Automod is already on.")

        await c.execute("INSERT INTO automod(guild_id, antiword, antispam, antilink) VALUES(?,?,?,?)", (ctx.guild.id, 'on', 'on', 'on'))
        await ctx.send("Done")

        await self.bot.db.commit()

    @automod.command()
    async def disable(self, ctx):
        c = await self.bot.db.cursor()
        await c.execute("SELECT antiword, antilink, antispam FROM automod WHERE guild_id = ?", (ctx.guild.id,))
        re = await c.fetchone()

        if re is None: return await ctx.send("automod is not on")

        await c.execute(f"DELETE FROM automod WHERE guild_id = ?", (ctx.guild.id,))
        await ctx.send("Done")
        await self.bot.db.commit()

    @commands.Cog.listener('on_message')
    async def antimod(self, msg: discord.Message):
        if msg.author.bot or msg.author.guild_permissions.administrator: return

        c = await self.bot.db.cursor()
        await c.execute(f"select antiword, antilink, antispam FROM automod WHERE guild_id = ?", (msg.guild.id,))
        re = await c.fetchone()
        if re is None: return

        word = ['Maadrchod','randi' ,'jahtu' , 'bsdk' , 'rand', 'Teri maa ki chut', 'jhat' ,'chinal' , 'tatta' , 'aand' , 'bhen k land' , 'kutte k pille chut' , 'land' , 'lowda' ,'Lura',]

        if re[0] == 'on':
            if 'discord.gg/' in msg.content.lower() or 'https://' in msg.content.lower():
                await msg.delete()
                await msg.channel.send("Links not allowed.", delete_after=1)
        if re[1] == 'on':
            for w in word:
                if w.lower() in msg.content.lower():
                    await msg.delete()
                    await msg.channel.send("No badword.", delete_after=1)
        if re[2] == 'on':
            bucket = self.cd.get_bucket(msg)
            retry = bucket.update_rate_limit()
            if retry: 
                await msg.delete()
                await msg.channel.send("No spamming", delete_after=1)
                await msg.author.timeout(discord.utils.utcnow()+datetime.timedelta(days=1))
                await msg.channel.send(f"Muted {msg.author.mention}")



async def setup(bot):
    await bot.add_cog(AutoModeration(bot))