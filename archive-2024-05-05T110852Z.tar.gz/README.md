da# lnl-prime
source code pulled and dropped by team indie, token n00ked and d00ked on this bot is skidded off wock, another source we pulled that ended up getting leaked anyways even tho i told the owner i wouldnt leak it due to shit like this happening where skids have a playday.

# Credits 
 Invisible 
